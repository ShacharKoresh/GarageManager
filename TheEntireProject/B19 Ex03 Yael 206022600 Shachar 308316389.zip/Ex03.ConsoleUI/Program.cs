﻿using System;
using System.Collections.Generic;

namespace Ex03.ConsoleUI
{
    public class Program
    {
        public static void Main()
        {
            GarageUI.RunGarage();
        }
    }
}
